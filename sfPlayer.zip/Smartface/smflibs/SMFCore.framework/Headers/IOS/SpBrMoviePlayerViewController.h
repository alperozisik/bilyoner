//
//  SpBrMoviePlayerViewController.h
//  SpratIOS
//
//  Created by Antti Panula on 7/16/13.
//  Copyright (c) 2013 Bivium. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>

@interface SpBrMoviePlayerViewController : MPMoviePlayerViewController

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation;
@end
