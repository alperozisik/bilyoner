/*
 * SpBrNuiAdViewIOS.h
 *
 *  Created on: Jan 17, 2012
 *      Author: antti
 */

#ifndef SPBRNUIADVIEWIOS_H_
#define SPBRNUIADVIEWIOS_H_

#include "Core/SpBrNuiAdView.h"

class SpBrNuiAdViewIOS: public SpBrNuiAdView {
public:
	SpBrNuiAdViewIOS(SpBrBase* base, SpContext* context);
    SpBrNuiAdViewIOS(SpBrNuiAdViewIOS* objectToCopy);
	virtual ~SpBrNuiAdViewIOS();
	void Load();
    void Invalidate(bool skipMainProperty = false);
    void loadAdRequest();
    void SetRootViewController(void* vc);

private:
    void *adReporter;
};

#endif /* SPBRNUIADVIEWIOS_H_ */
